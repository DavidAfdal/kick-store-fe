import review1 from '../assets/Image/review1.jpg';
import review2 from '../assets/Image/review2.png';
import review3 from '../assets/Image/review3.png';
import review4 from '../assets/Image/review4.jpg';
import review5 from '../assets/Image/review5.webp';
import profile1 from "../assets/Image/profile1.jpeg"
import profile2 from "../assets/Image/profile6.jpg"
import profile3 from "../assets/Image/profile3.jpg"
import profile4 from "../assets/Image/profile4.jpg"
import profile5 from "../assets/Image/profile5.jfif"

export const Revview = [
  {
    nama: 'David Afdal Kaizar mutahadi',
    review: 'I highly recommend shopping from kicks',
    profileImg: profile2,
    rating: 5,
    productImhg: review5,
  },
  {
    nama: 'I Kadek Andika',
    review: 'I highly recommend shopping from kicks',
    profileImg: profile5,
    rating: 5,
    productImhg: review1,
  },
  {
    nama: 'Sheehan Rafee Effendi',
    review: 'I highly recommend shopping from kicks',
    profileImg: profile4,
    rating: 5,
    productImhg: review3,
  },
  {
    nama: 'Fachri Taufiqurrahman',
    review: 'I highly recommend shopping from kicks',
    profileImg: profile1,
    rating: 5,
    productImhg: review2,
  },
  {
    nama: 'Bright David Andreas',
    review: 'I highly recommend shopping from kicks',
    profileImg: profile3,
    rating: 4,
    productImhg: review4,
  },


];

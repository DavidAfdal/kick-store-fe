export type ColorModel = {
  nama: string;
  color: string;
};

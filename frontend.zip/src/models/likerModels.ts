
export type LikesModel = {
  id: number;
  name: string;
  price: number;
  diskon: number;
  thumbImg: string;
  createdAt: Date;
  like: boolean;
};

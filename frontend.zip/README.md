Langkah - langkah untuk menjalankan program :
1. pastikan sudah menginstal node js. 
2. Git clone atau download file di repository ini.
3. Setelah selesai git clone/download, buka filenya di vscode.
4. dibagian terminal vscode tuliskan npm i.
5. Jalankan program dengan mengetikan npm run dev di terminal vscode.




